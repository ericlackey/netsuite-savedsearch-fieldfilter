# netsuite-savedsearch-fieldfilter
NetSuite Saved Search Field Filter


### 0.5
Change background color to match native Saved Search background color
Fix issue where filter wasn't working correctly when editing/creating Transaction searches


### 0.4

- Fix issue causing errors on iFRAME
- Prevent script IDs from going from lowercase to uppercase
- Include blank span for non-transaction searches for consistency and to prevent input search box from moving to left
